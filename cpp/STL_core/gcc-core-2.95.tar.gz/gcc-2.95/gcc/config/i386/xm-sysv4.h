/* Configuration for GCC for Intel i386 running System V Release 4.  */

#ifdef __HIGHC__
#include <alloca.h>		/* for MetaWare High-C on NCR System 3000 */
#endif
