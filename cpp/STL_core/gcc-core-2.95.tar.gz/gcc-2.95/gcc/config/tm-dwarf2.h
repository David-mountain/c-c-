/* Enable Dwarf2 debugging and make it the default */
#define  DWARF2_DEBUGGING_INFO 1
#define  PREFERRED_DEBUGGING_TYPE  DWARF2_DEBUG

