#include <stdio.h>
int main(void){char*p="#include <stdio.h>%cint main(void){char*p=%c%s%c;(void)printf(p,10,34,p,34,10);return 0;}%c";(void)printf(p,10,34,p,34,10);return 0;}
