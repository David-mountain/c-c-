char *version_string = "2.95 19990728 (release)";
